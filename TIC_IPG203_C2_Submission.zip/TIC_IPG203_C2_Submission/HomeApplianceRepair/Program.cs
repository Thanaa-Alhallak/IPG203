using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using HomeApplianceRepair.Enums;
using HomeApplianceRepair.Helpers;
using HomeApplianceRepair.Models;
using HomeApplianceRepair.Services;

namespace HomeApplianceRepair
{
    /// <summary>Console menu - the entry point of the program.</summary>
    internal static class Program
    {
        private const int OverdueThresholdDays = 3;

        private static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
            CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;

            RepairCenter center = new RepairCenter();

            // Subscribe to the events of the center
            center.ApplianceStatusChanged += OnStatusChanged;
            center.DeliveryOverdue += OnDeliveryOverdue;

            bool running = true;
            while (running)
            {
                ShowMenu();
                string choice = Console.ReadLine();
                Console.WriteLine();

                try
                {
                    switch ((choice ?? "").Trim())
                    {
                        case "1": RegisterAppliance(center); break;
                        case "2": StartRepair(center); break;
                        case "3": CompleteRepair(center); break;
                        case "4": DeliverAppliance(center); break;
                        case "5": PrintList("All appliances", center.Appliances); break;
                        case "6": PrintList("Repaired appliances", center.GetRepaired()); break;
                        case "7": PrintList("Appliances still in repair", center.GetStillInRepair()); break;
                        case "8": CheckOverdue(center); break;
                        case "9": ShowStatistics(center); break;
                        case "10": LoadSampleData(center); break;
                        case "0": running = false; break;
                        default: Console.WriteLine("Invalid choice, please try again."); break;
                    }
                }
                catch (Exception ex) when (ex is ArgumentException || ex is InvalidOperationException)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error: " + ex.Message);
                    Console.ResetColor();
                }
            }

            Console.WriteLine("Goodbye!");
        }

        // ------------------------------------------------------------------ menu
        private static void ShowMenu()
        {
            Console.WriteLine();
            Console.WriteLine("===== Home Appliance Repair Center =====");
            Console.WriteLine(" 1. Register a new appliance");
            Console.WriteLine(" 2. Start repair");
            Console.WriteLine(" 3. Complete repair");
            Console.WriteLine(" 4. Deliver appliance to customer");
            Console.WriteLine(" 5. Show all appliances");
            Console.WriteLine(" 6. Show repaired appliances");
            Console.WriteLine(" 7. Show appliances still in repair");
            Console.WriteLine(" 8. Check overdue deliveries");
            Console.WriteLine(" 9. Show statistics");
            Console.WriteLine("10. Load sample data");
            Console.WriteLine(" 0. Exit");
            Console.Write("Your choice: ");
        }

        // --------------------------------------------------------- menu actions
        private static void RegisterAppliance(RepairCenter center)
        {
            Console.WriteLine("Appliance type: 1) Refrigerator  2) Washing Machine  3) Air Conditioner");
            int type = ReadInt("Type: ", 1, 3);

            string serial = ReadValid("Serial number (e.g. FR-1001): ", Validator.IsValidSerialNumber,
                                      "Use two capital letters, a dash and four digits.", true);
            string brand = ReadValid("Brand: ", s => Validator.IsValidText(s, 2, 30),
                                     "Brand must be between 2 and 30 characters.", false);
            string customer = ReadValid("Customer name: ", Validator.IsValidName,
                                        "Letters and spaces only (2 to 40 characters).", false);
            string fault = ReadValid("Fault description: ", s => Validator.IsValidText(s, 3, 100),
                                     "Description must be between 3 and 100 characters.", false);
            DateTime received = ReadDate("Received date (yyyy-MM-dd, Enter = today): ");

            Appliance appliance;
            switch (type)
            {
                case 1:
                    int liters = ReadInt("Capacity in liters: ", 1, 1000);
                    bool gas = ReadYesNo("Needs gas refill? (y/n): ");
                    appliance = new Refrigerator(serial, brand, customer, fault, received, liters, gas);
                    break;
                case 2:
                    int kg = ReadInt("Load capacity in kg: ", 1, 30);
                    bool drum = ReadYesNo("Needs drum replacement? (y/n): ");
                    appliance = new WashingMachine(serial, brand, customer, fault, received, kg, drum);
                    break;
                default:
                    double tons = ReadDouble("Cooling capacity in tons (e.g. 1.5): ", 0.5, 10);
                    bool visit = ReadYesNo("Needs an on-site visit? (y/n): ");
                    appliance = new AirConditioner(serial, brand, customer, fault, received, tons, visit);
                    break;
            }

            center.Register(appliance);
            Console.WriteLine("Registered: " + appliance.GetSummary());
        }

        private static void StartRepair(RepairCenter center)
        {
            string serial = ReadSerial();
            center.StartRepair(serial);
        }

        private static void CompleteRepair(RepairCenter center)
        {
            string serial = ReadSerial();
            decimal parts = ReadDecimal("Parts cost in $: ", 0, 5000);
            double hours = ReadDouble("Labor hours: ", 0, 100);
            center.CompleteRepair(serial, parts, hours);

            Appliance appliance = center.FindBySerial(serial);
            Console.WriteLine("Repair cost: {0:F2} $", appliance.CalculateRepairCost());
        }

        private static void DeliverAppliance(RepairCenter center)
        {
            string serial = ReadSerial();
            center.Deliver(serial);
        }

        private static void CheckOverdue(RepairCenter center)
        {
            int count = center.CheckOverdueDeliveries(OverdueThresholdDays);
            Console.WriteLine("Overdue appliances (waiting {0}+ days): {1}", OverdueThresholdDays, count);
        }

        private static void ShowStatistics(RepairCenter center)
        {
            Console.WriteLine("---- Statistics ----");
            Console.WriteLine("Appliances created (static counter): " + Appliance.CreatedCount);

            foreach (RepairStatus status in Enum.GetValues(typeof(RepairStatus)))
            {
                Console.WriteLine("  {0,-10}: {1}", status, RepairStatistics.CountByStatus(center.Appliances, status));
            }

            Console.WriteLine("Total of all repair costs     : {0:F2} $", center.CalculateTotalCosts());
            Console.WriteLine("Delivered appliances          : " + RepairStatistics.DeliveredCount);
            Console.WriteLine("Revenue from delivered items  : {0:F2} $", RepairStatistics.TotalRevenue);
            Console.WriteLine("Average bill (delivered)      : {0:F2} $", RepairStatistics.AverageTicket);
        }

        private static void PrintList(string title, IEnumerable<Appliance> items)
        {
            List<Appliance> list = items.ToList();
            Console.WriteLine("---- {0} ({1}) ----", title, list.Count);

            if (list.Count == 0)
            {
                Console.WriteLine("(none)");
                return;
            }

            foreach (Appliance item in list)
            {
                Console.WriteLine(item.GetSummary());
            }
        }

        private static void LoadSampleData(RepairCenter center)
        {
            DateTime today = DateTime.Today;

            Appliance fridge = new Refrigerator("FR-1001", "Samsung", "Ahmad Khaled", "Not cooling", today.AddDays(-14), 450, true);
            Appliance washer = new WashingMachine("WM-2001", "LG", "Rana Haddad", "Drum is not spinning", today.AddDays(-6), 8, true);
            Appliance cooler = new AirConditioner("AC-3001", "Carrier", "Omar Nasser", "Water leaking", today.AddDays(-3), 1.5, false);
            Appliance fridge2 = new Refrigerator("FR-1002", "Bosch", "Lina Saleh", "Strange noise", today.AddDays(-1), 300, false);

            center.Register(fridge);
            center.Register(washer);
            center.Register(cooler);
            center.Register(fridge2);

            // FR-1001: repaired 9 days ago and never picked up -> will trigger the overdue alert
            center.StartRepair("FR-1001");
            fridge.PartsCost = 55m;
            fridge.LaborHours = 2.5;
            fridge.CompleteRepair(DateTime.Now.AddDays(-9));

            // WM-2001: currently being repaired
            center.StartRepair("WM-2001");
            washer.PartsCost = 30m;
            washer.LaborHours = 1.5;

            Console.WriteLine("Sample data loaded: 4 appliances.");
        }

        // ---------------------------------------------------- event subscribers
        private static void OnStatusChanged(Appliance appliance, RepairStatus oldStatus, RepairStatus newStatus)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("[NOTIFICATION] {0} ({1}): {2} -> {3}",
                              appliance.SerialNumber, appliance.CustomerName, oldStatus, newStatus);
            Console.ResetColor();
        }

        private static void OnDeliveryOverdue(Appliance appliance, int daysWaiting)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("[ALERT] {0} ({1}) has been waiting {2} day(s) for pickup!",
                              appliance.SerialNumber, appliance.CustomerName, daysWaiting);
            Console.ResetColor();
        }

        // ------------------------------------------------------- input helpers
        private static string ReadSerial()
        {
            return ReadValid("Serial number: ", Validator.IsValidSerialNumber,
                             "Use two capital letters, a dash and four digits.", true);
        }

        private static string ReadValid(string prompt, Func<string, bool> isValid, string error, bool upperCase)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = (Console.ReadLine() ?? "").Trim();
                if (upperCase)
                    input = input.ToUpperInvariant();

                if (isValid(input))
                    return input;

                Console.WriteLine("  ! " + error);
            }
        }

        private static int ReadInt(string prompt, int min, int max)
        {
            while (true)
            {
                Console.Write(prompt);
                int value;
                if (int.TryParse(Console.ReadLine(), NumberStyles.Integer, CultureInfo.InvariantCulture, out value)
                    && value >= min && value <= max)
                    return value;

                Console.WriteLine("  ! Enter a whole number between {0} and {1}.", min, max);
            }
        }

        private static double ReadDouble(string prompt, double min, double max)
        {
            while (true)
            {
                Console.Write(prompt);
                double value;
                if (double.TryParse(Console.ReadLine(), NumberStyles.Float, CultureInfo.InvariantCulture, out value)
                    && value >= min && value <= max)
                    return value;

                Console.WriteLine("  ! Enter a number between {0} and {1}.", min, max);
            }
        }

        private static decimal ReadDecimal(string prompt, decimal min, decimal max)
        {
            while (true)
            {
                Console.Write(prompt);
                decimal value;
                if (decimal.TryParse(Console.ReadLine(), NumberStyles.Number, CultureInfo.InvariantCulture, out value)
                    && value >= min && value <= max)
                    return value;

                Console.WriteLine("  ! Enter an amount between {0} and {1}.", min, max);
            }
        }

        private static bool ReadYesNo(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();
                if (input == "y" || input == "yes") return true;
                if (input == "n" || input == "no") return false;
                Console.WriteLine("  ! Please answer y or n.");
            }
        }

        private static DateTime ReadDate(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = (Console.ReadLine() ?? "").Trim();

                if (input.Length == 0)
                    return DateTime.Today;

                DateTime date;
                if (Validator.TryParseDate(input, out date) && Validator.IsValidReceivedDate(date))
                    return date;

                Console.WriteLine("  ! Use the format yyyy-MM-dd and a date that is not in the future.");
            }
        }
    }
}
