using System;
using HomeApplianceRepair.Enums;
using HomeApplianceRepair.Events;
using HomeApplianceRepair.Helpers;
using HomeApplianceRepair.Interfaces;

namespace HomeApplianceRepair.Models
{
    /// <summary>
    /// Abstract base class of every appliance. It implements IRepairable,
    /// holds the shared data and leaves the cost rule to the sub classes.
    /// </summary>
    public abstract class Appliance : IRepairable
    {
        // Prices shared by all appliances (constants, so they can never change at run time)
        public const decimal DiagnosticFee = 10m;
        public const decimal HourlyRate = 15m;

        // Static member: counts every appliance object ever created
        private static int _createdCount;

        // All fields are private
        private readonly string _serialNumber;
        private readonly DateTime _receivedDate;
        private string _brand;
        private string _customerName;
        private string _faultDescription;
        private decimal _partsCost;
        private double _laborHours;
        private RepairStatus _status;
        private DateTime? _readyDate;
        private DateTime? _deliveredDate;

        /// <summary>Raised every time the status of this appliance changes.</summary>
        public event StatusChangedHandler StatusChanged;

        protected Appliance(string serialNumber, string brand, string customerName,
                            string faultDescription, DateTime receivedDate)
        {
            if (!Validator.IsValidSerialNumber(serialNumber))
                throw new ArgumentException(
                    "Serial number must look like FR-1001 (two capital letters, a dash, four digits).",
                    nameof(serialNumber));

            if (!Validator.IsValidReceivedDate(receivedDate))
                throw new ArgumentException("Received date cannot be in the future.", nameof(receivedDate));

            _serialNumber = serialNumber;
            _receivedDate = receivedDate;
            _status = RepairStatus.Registered;

            // The properties below validate the values
            Brand = brand;
            CustomerName = customerName;
            FaultDescription = faultDescription;

            _createdCount++;
        }

        // ---------- Static property ----------
        public static int CreatedCount
        {
            get { return _createdCount; }
        }

        // ---------- Read-only properties (fixed once the object is created) ----------
        public string SerialNumber
        {
            get { return _serialNumber; }
        }

        public DateTime ReceivedDate
        {
            get { return _receivedDate; }
        }

        public RepairStatus Status
        {
            get { return _status; }
        }

        public DateTime? ReadyDate
        {
            get { return _readyDate; }
        }

        public DateTime? DeliveredDate
        {
            get { return _deliveredDate; }
        }

        // ---------- Properties with validation ----------
        public string Brand
        {
            get { return _brand; }
            set
            {
                if (!Validator.IsValidText(value, 2, 30))
                    throw new ArgumentException("Brand must be between 2 and 30 characters.", nameof(value));
                _brand = value.Trim();
            }
        }

        public string CustomerName
        {
            get { return _customerName; }
            set
            {
                if (!Validator.IsValidName(value))
                    throw new ArgumentException(
                        "Customer name must contain only letters and spaces (2 to 40 characters).", nameof(value));
                _customerName = value.Trim();
            }
        }

        public string FaultDescription
        {
            get { return _faultDescription; }
            set
            {
                if (!Validator.IsValidText(value, 3, 100))
                    throw new ArgumentException("Fault description must be between 3 and 100 characters.", nameof(value));
                _faultDescription = value.Trim();
            }
        }

        public decimal PartsCost
        {
            get { return _partsCost; }
            set
            {
                EnsureBillNotClosed();
                if (value < 0)
                    throw new ArgumentOutOfRangeException(nameof(value), "Parts cost cannot be negative.");
                _partsCost = value;
            }
        }

        public double LaborHours
        {
            get { return _laborHours; }
            set
            {
                EnsureBillNotClosed();
                if (value < 0 || value > 100)
                    throw new ArgumentOutOfRangeException(nameof(value), "Labor hours must be between 0 and 100.");
                _laborHours = value;
            }
        }

        /// <summary>Number of days a repaired appliance has been waiting for the customer.</summary>
        public int DaysWaitingForPickup
        {
            get
            {
                if (_status != RepairStatus.Ready || !_readyDate.HasValue)
                    return 0;
                return (int)(DateTime.Now - _readyDate.Value).TotalDays;
            }
        }

        // ---------- Abstract members: every sub class must provide its own version ----------
        public abstract string ApplianceType { get; }

        public abstract decimal CalculateRepairCost();

        // ---------- Life cycle ----------
        public void StartRepair()
        {
            EnsureStatus(RepairStatus.Registered, "start the repair");
            ChangeStatus(RepairStatus.InRepair);
        }

        public void CompleteRepair()
        {
            CompleteRepair(DateTime.Now);
        }

        /// <summary>Completes the repair and records the date on which the appliance became ready.</summary>
        public void CompleteRepair(DateTime readyOn)
        {
            EnsureStatus(RepairStatus.InRepair, "complete the repair");

            if (readyOn < _receivedDate || readyOn > DateTime.Now)
                throw new ArgumentException("Ready date must be between the received date and now.", nameof(readyOn));

            _readyDate = readyOn;
            ChangeStatus(RepairStatus.Ready);
        }

        public void Deliver()
        {
            EnsureStatus(RepairStatus.Ready, "deliver the appliance");
            _deliveredDate = DateTime.Now;
            ChangeStatus(RepairStatus.Delivered);
        }

        public virtual string GetSummary()
        {
            return string.Format("[{0}] {1,-15} | {2,-10} | {3,-15} | {4,-10} | {5,8:F2} $",
                                 SerialNumber, ApplianceType, Brand, CustomerName, Status, CalculateRepairCost());
        }

        // ---------- Helpers for the sub classes ----------

        /// <summary>The part of the bill that is the same for every appliance type.</summary>
        protected decimal BaseCost()
        {
            return DiagnosticFee + _partsCost + (decimal)_laborHours * HourlyRate;
        }

        protected virtual void OnStatusChanged(RepairStatus oldStatus, RepairStatus newStatus)
        {
            if (StatusChanged != null)
                StatusChanged(this, oldStatus, newStatus);
        }

        // ---------- Private helpers ----------
        private void ChangeStatus(RepairStatus newStatus)
        {
            RepairStatus oldStatus = _status;
            _status = newStatus;
            OnStatusChanged(oldStatus, newStatus);
        }

        private void EnsureStatus(RepairStatus expected, string action)
        {
            if (_status != expected)
                throw new InvalidOperationException(string.Format(
                    "Cannot {0}: appliance {1} is '{2}' but must be '{3}'.", action, SerialNumber, _status, expected));
        }

        private void EnsureBillNotClosed()
        {
            if (_status == RepairStatus.Delivered)
                throw new InvalidOperationException("The bill is closed: a delivered appliance cannot be modified.");
        }
    }
}
