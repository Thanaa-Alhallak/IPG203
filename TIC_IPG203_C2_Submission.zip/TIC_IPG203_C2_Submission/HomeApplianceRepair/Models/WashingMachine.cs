using System;

namespace HomeApplianceRepair.Models
{
    public class WashingMachine : Appliance
    {
        private const decimal DrumKitFee = 60m;
        private const decimal PerKgFee = 4m;

        private readonly int _loadCapacityKg;
        private readonly bool _needsDrumReplacement;

        public WashingMachine(string serialNumber, string brand, string customerName,
                              string faultDescription, DateTime receivedDate,
                              int loadCapacityKg, bool needsDrumReplacement)
            : base(serialNumber, brand, customerName, faultDescription, receivedDate)
        {
            if (loadCapacityKg <= 0 || loadCapacityKg > 30)
                throw new ArgumentOutOfRangeException(nameof(loadCapacityKg), "Load capacity must be between 1 and 30 kg.");

            _loadCapacityKg = loadCapacityKg;
            _needsDrumReplacement = needsDrumReplacement;
        }

        public int LoadCapacityKg
        {
            get { return _loadCapacityKg; }
        }

        public bool NeedsDrumReplacement
        {
            get { return _needsDrumReplacement; }
        }

        public override string ApplianceType
        {
            get { return "Washing Machine"; }
        }

        // Washing machine rule: base cost + (drum kit + a fee per kg of capacity) when the drum is replaced
        public override decimal CalculateRepairCost()
        {
            decimal cost = BaseCost();

            if (_needsDrumReplacement)
                cost += DrumKitFee + _loadCapacityKg * PerKgFee;

            return cost;
        }

        public override string GetSummary()
        {
            return base.GetSummary() + " | " + _loadCapacityKg + " kg" + (_needsDrumReplacement ? " | new drum" : "");
        }
    }
}
