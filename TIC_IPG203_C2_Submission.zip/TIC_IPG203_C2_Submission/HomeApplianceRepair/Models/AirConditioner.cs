using System;

namespace HomeApplianceRepair.Models
{
    public class AirConditioner : Appliance
    {
        private const decimal TonRate = 25m;
        private const decimal OnSiteVisitFee = 30m;

        private readonly double _tonnage;
        private readonly bool _needsOnSiteVisit;

        public AirConditioner(string serialNumber, string brand, string customerName,
                              string faultDescription, DateTime receivedDate,
                              double tonnage, bool needsOnSiteVisit)
            : base(serialNumber, brand, customerName, faultDescription, receivedDate)
        {
            if (tonnage <= 0 || tonnage > 10)
                throw new ArgumentOutOfRangeException(nameof(tonnage), "Tonnage must be between 0 and 10.");

            _tonnage = tonnage;
            _needsOnSiteVisit = needsOnSiteVisit;
        }

        public double Tonnage
        {
            get { return _tonnage; }
        }

        public bool NeedsOnSiteVisit
        {
            get { return _needsOnSiteVisit; }
        }

        public override string ApplianceType
        {
            get { return "Air Conditioner"; }
        }

        // Air conditioner rule: base cost + a fee per ton of cooling + an optional on-site visit
        public override decimal CalculateRepairCost()
        {
            decimal cost = BaseCost() + (decimal)_tonnage * TonRate;

            if (_needsOnSiteVisit)
                cost += OnSiteVisitFee;

            return cost;
        }

        public override string GetSummary()
        {
            return base.GetSummary() + " | " + _tonnage + " ton" + (_needsOnSiteVisit ? " | on-site" : "");
        }
    }
}
