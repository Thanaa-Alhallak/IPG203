using System;

namespace HomeApplianceRepair.Models
{
    public class Refrigerator : Appliance
    {
        private const decimal GasRefillFee = 45m;
        private const decimal LargeUnitSurcharge = 20m;
        private const int LargeUnitLiters = 400;

        private readonly int _capacityLiters;
        private readonly bool _needsGasRefill;

        public Refrigerator(string serialNumber, string brand, string customerName,
                            string faultDescription, DateTime receivedDate,
                            int capacityLiters, bool needsGasRefill)
            : base(serialNumber, brand, customerName, faultDescription, receivedDate)
        {
            if (capacityLiters <= 0 || capacityLiters > 1000)
                throw new ArgumentOutOfRangeException(nameof(capacityLiters), "Capacity must be between 1 and 1000 liters.");

            _capacityLiters = capacityLiters;
            _needsGasRefill = needsGasRefill;
        }

        public int CapacityLiters
        {
            get { return _capacityLiters; }
        }

        public bool NeedsGasRefill
        {
            get { return _needsGasRefill; }
        }

        public override string ApplianceType
        {
            get { return "Refrigerator"; }
        }

        // Refrigerator rule: base cost + gas refill + surcharge for big units
        public override decimal CalculateRepairCost()
        {
            decimal cost = BaseCost();

            if (_needsGasRefill)
                cost += GasRefillFee;

            if (_capacityLiters >= LargeUnitLiters)
                cost += LargeUnitSurcharge;

            return cost;
        }

        public override string GetSummary()
        {
            return base.GetSummary() + " | " + _capacityLiters + " L" + (_needsGasRefill ? " | gas refill" : "");
        }
    }
}
