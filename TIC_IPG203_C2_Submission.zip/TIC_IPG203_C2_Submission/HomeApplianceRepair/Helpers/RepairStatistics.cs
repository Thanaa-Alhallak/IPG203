using System.Collections.Generic;
using System.Linq;
using HomeApplianceRepair.Enums;
using HomeApplianceRepair.Interfaces;

namespace HomeApplianceRepair.Helpers
{
    /// <summary>
    /// Static class that keeps the totals of the whole center.
    /// TotalRevenue and DeliveredCount are static properties shared by every part of the program.
    /// </summary>
    public static class RepairStatistics
    {
        public static decimal TotalRevenue { get; private set; }

        public static int DeliveredCount { get; private set; }

        public static decimal AverageTicket
        {
            get { return DeliveredCount == 0 ? 0m : TotalRevenue / DeliveredCount; }
        }

        public static void RecordDelivery(decimal amount)
        {
            TotalRevenue += amount;
            DeliveredCount++;
        }

        /// <summary>Counts how many appliances are currently in the given status.</summary>
        public static int CountByStatus(IEnumerable<IRepairable> appliances, RepairStatus status)
        {
            return appliances.Count(a => a.Status == status);
        }
    }
}
