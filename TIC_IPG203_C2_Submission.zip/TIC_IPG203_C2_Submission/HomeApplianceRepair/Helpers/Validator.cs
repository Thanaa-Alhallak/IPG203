using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace HomeApplianceRepair.Helpers
{
    /// <summary>
    /// Static class that validates every value typed by the user.
    /// It has no state, so there is no reason to ever create an object of it.
    /// </summary>
    public static class Validator
    {
        // Two capital letters, a dash and four digits. Example: FR-1001
        private static readonly Regex SerialPattern =
            new Regex("^[A-Z]{2}-[0-9]{4}$", RegexOptions.CultureInvariant);

        public const string DateFormat = "yyyy-MM-dd";

        public static bool IsValidSerialNumber(string serialNumber)
        {
            return !string.IsNullOrWhiteSpace(serialNumber) && SerialPattern.IsMatch(serialNumber);
        }

        public static bool IsValidName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return false;

            string trimmed = name.Trim();
            if (trimmed.Length < 2 || trimmed.Length > 40)
                return false;

            foreach (char c in trimmed)
            {
                if (!char.IsLetter(c) && c != ' ' && c != '-')
                    return false;
            }
            return true;
        }

        public static bool IsValidText(string text, int minLength, int maxLength)
        {
            if (string.IsNullOrWhiteSpace(text))
                return false;

            int length = text.Trim().Length;
            return length >= minLength && length <= maxLength;
        }

        public static bool TryParseDate(string text, out DateTime date)
        {
            return DateTime.TryParseExact(text, DateFormat, CultureInfo.InvariantCulture,
                                          DateTimeStyles.None, out date);
        }

        /// <summary>An appliance cannot have been received in the future.</summary>
        public static bool IsValidReceivedDate(DateTime date)
        {
            return date.Date <= DateTime.Today;
        }
    }
}
