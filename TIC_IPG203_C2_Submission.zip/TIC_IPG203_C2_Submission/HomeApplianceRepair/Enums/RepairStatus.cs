namespace HomeApplianceRepair.Enums
{
    /// <summary>
    /// Life cycle of an appliance inside the repair center.
    /// The only legal order is: Registered -> InRepair -> Ready -> Delivered.
    /// </summary>
    public enum RepairStatus
    {
        Registered,   // received from the customer, waiting for a technician
        InRepair,     // a technician is working on it
        Ready,        // repaired, waiting for the customer to pick it up
        Delivered     // handed back to the customer
    }
}
