# Home Appliance Repair Center (C#)

TIC_IPG203_F25 - OOP assignment. A console application that manages a home appliance repair center.

## OOP concepts used
| Concept | Where |
|---|---|
| Abstraction | `Interfaces/IRepairable.cs`, abstract class `Models/Appliance.cs` |
| Inheritance & Polymorphism | `Refrigerator`, `WashingMachine`, `AirConditioner`, `List<Appliance>` in `Services/RepairCenter.cs` |
| Encapsulation | private fields + properties, read-only serial number, closed bill after delivery |
| Delegates & Events | `Events/RepairEvents.cs`, `StatusChanged`, `DeliveryOverdue` |
| Static classes / members | `Helpers/Validator.cs`, `Helpers/RepairStatistics.cs`, `Appliance.CreatedCount` |

## Run
```
dotnet run
```
(or open `HomeApplianceRepair.csproj` in Visual Studio 2022 and press Ctrl+F5).
Use menu option **10** to load sample data.
