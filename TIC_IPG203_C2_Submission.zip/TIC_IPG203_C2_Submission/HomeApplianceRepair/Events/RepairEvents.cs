using HomeApplianceRepair.Enums;
using HomeApplianceRepair.Models;

namespace HomeApplianceRepair.Events
{
    /// <summary>Signature of the notification sent when an appliance changes its status.</summary>
    public delegate void StatusChangedHandler(Appliance appliance, RepairStatus oldStatus, RepairStatus newStatus);

    /// <summary>Signature of the alert sent when a repaired appliance is not picked up in time.</summary>
    public delegate void DeliveryOverdueHandler(Appliance appliance, int daysWaiting);
}
