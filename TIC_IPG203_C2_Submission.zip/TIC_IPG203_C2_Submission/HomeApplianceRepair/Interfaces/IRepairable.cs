using HomeApplianceRepair.Enums;

namespace HomeApplianceRepair.Interfaces
{
    /// <summary>
    /// The basic operations shared by every appliance the center can repair.
    /// It contains no implementation details at all (Abstraction).
    /// </summary>
    public interface IRepairable
    {
        string SerialNumber { get; }
        RepairStatus Status { get; }

        decimal CalculateRepairCost();
        void StartRepair();
        void CompleteRepair();
        void Deliver();
        string GetSummary();
    }
}
