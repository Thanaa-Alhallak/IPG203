using System;
using System.Collections.Generic;
using System.Linq;
using HomeApplianceRepair.Enums;
using HomeApplianceRepair.Events;
using HomeApplianceRepair.Helpers;
using HomeApplianceRepair.Models;

namespace HomeApplianceRepair.Services
{
    /// <summary>
    /// The main class of the system. It keeps a List of Appliance and treats every
    /// element through the base type, so each one uses its own cost rule (Polymorphism).
    /// </summary>
    public class RepairCenter
    {
        private readonly List<Appliance> _appliances = new List<Appliance>();

        /// <summary>Forwards the status change of any appliance to whoever is listening.</summary>
        public event StatusChangedHandler ApplianceStatusChanged;

        /// <summary>Raised for every repaired appliance that waits too long for pickup.</summary>
        public event DeliveryOverdueHandler DeliveryOverdue;

        public IReadOnlyList<Appliance> Appliances
        {
            get { return _appliances.AsReadOnly(); }
        }

        public void Register(Appliance appliance)
        {
            if (appliance == null)
                throw new ArgumentNullException(nameof(appliance));

            if (FindBySerial(appliance.SerialNumber) != null)
                throw new InvalidOperationException(
                    "An appliance with serial number " + appliance.SerialNumber + " is already registered.");

            appliance.StatusChanged += HandleStatusChanged;
            _appliances.Add(appliance);
        }

        public Appliance FindBySerial(string serialNumber)
        {
            return _appliances.FirstOrDefault(a =>
                string.Equals(a.SerialNumber, serialNumber, StringComparison.OrdinalIgnoreCase));
        }

        public void StartRepair(string serialNumber)
        {
            GetOrThrow(serialNumber).StartRepair();
        }

        public void CompleteRepair(string serialNumber, decimal partsCost, double laborHours)
        {
            Appliance appliance = GetOrThrow(serialNumber);

            if (appliance.Status != RepairStatus.InRepair)
                throw new InvalidOperationException(
                    "Appliance " + appliance.SerialNumber + " is not under repair.");

            appliance.PartsCost = partsCost;
            appliance.LaborHours = laborHours;
            appliance.CompleteRepair();
        }

        public void Deliver(string serialNumber)
        {
            GetOrThrow(serialNumber).Deliver();
        }

        public IEnumerable<Appliance> GetByStatus(RepairStatus status)
        {
            return _appliances.Where(a => a.Status == status);
        }

        /// <summary>Appliances that were repaired (ready or already delivered).</summary>
        public IEnumerable<Appliance> GetRepaired()
        {
            return _appliances.Where(a => a.Status == RepairStatus.Ready || a.Status == RepairStatus.Delivered);
        }

        /// <summary>Appliances that are still waiting for the repair or being repaired.</summary>
        public IEnumerable<Appliance> GetStillInRepair()
        {
            return _appliances.Where(a => a.Status == RepairStatus.Registered || a.Status == RepairStatus.InRepair);
        }

        /// <summary>Polymorphism: each appliance computes its own cost through the same call.</summary>
        public decimal CalculateTotalCosts()
        {
            decimal total = 0m;
            foreach (Appliance appliance in _appliances)
            {
                total += appliance.CalculateRepairCost();
            }
            return total;
        }

        /// <summary>Raises DeliveryOverdue for each appliance that has waited at least the given days.</summary>
        public int CheckOverdueDeliveries(int thresholdDays)
        {
            int overdue = 0;

            foreach (Appliance appliance in _appliances)
            {
                if (appliance.Status == RepairStatus.Ready && appliance.DaysWaitingForPickup >= thresholdDays)
                {
                    overdue++;
                    if (DeliveryOverdue != null)
                        DeliveryOverdue(appliance, appliance.DaysWaitingForPickup);
                }
            }

            return overdue;
        }

        private Appliance GetOrThrow(string serialNumber)
        {
            Appliance appliance = FindBySerial(serialNumber);
            if (appliance == null)
                throw new InvalidOperationException("No appliance found with serial number " + serialNumber + ".");
            return appliance;
        }

        private void HandleStatusChanged(Appliance appliance, RepairStatus oldStatus, RepairStatus newStatus)
        {
            if (newStatus == RepairStatus.Delivered)
                RepairStatistics.RecordDelivery(appliance.CalculateRepairCost());

            if (ApplianceStatusChanged != null)
                ApplianceStatusChanged(appliance, oldStatus, newStatus);
        }
    }
}
